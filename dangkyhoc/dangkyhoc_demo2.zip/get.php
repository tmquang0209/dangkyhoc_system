<?php
$arr = 157;

$data = file_get_contents("https://tlu-gules.vercel.app/api/$arr");

// $data = json_decode($data);
$myfile = fopen("data/$arr.txt", "w");
fwrite($myfile, $data);
fclose($myfile);
?>